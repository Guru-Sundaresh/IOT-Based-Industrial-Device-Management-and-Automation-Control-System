#include<lpc21xx.h>
#include"delay.h"
#include"lcd.h"
#include"uart.h"
#include<string.h>


int main()
{
unsigned char out;
unsigned int i=0,len=1;
unsigned char s[]="IOT BASED INDUSTRIAL DEVICE CONTROL AND AUTOMATION SYSTEM";
len=strlen(s);
LCD_init();
while(1)
{
if(i==len)
{
break;
}
LCD_cmd(0x01);
LCD_cmd(0x80);
LCD_str(s+(i++));
LCD_cmd(0xc0);
LCD_str("                ");
delay_ms(500);
//LCD_cmd(0x01);
} 
UART0_init();
LCD_cmd(0x80);
LCD_str("IOT Based Module");
IODIR0|=(1<<3)|(1<<4)|(1<<5)|(1<<6);
IOSET0|=(1<<3)|(1<<4)|(1<<5)|(1<<6);

while(1)
{
LCD_cmd(0x01);
LCD_cmd(0x80);
LCD_str("IOT Based Module");

out = UART0_RX();

switch(out)
{
case '1':LCD_cmd(0xc0);
		 LCD_str("Bulb 1 is ON");
		 IOCLR0|=1<<3;
		 delay_s(2);
		 break;
case '2':LCD_cmd(0xc0);
		 LCD_str("Bulb 1 is OFF");
		 IOSET0|=1<<3;
		 delay_s(2);
		 break;
case '3':LCD_cmd(0xc0);
		 LCD_str("Bulb 2 is ON");
		 IOCLR0|=1<<4;
		 delay_s(2);
		 break;
case '4':LCD_cmd(0xc0);
		 LCD_str("Bulb 2 is OFF");
		 IOSET0|=1<<4;
		 delay_s(2);
		 break;
case '5':LCD_cmd(0xc0);
		 LCD_str("Bulb 3 is ON");
		 IOCLR0|=1<<5;
		 delay_s(2);
		 break;
case '6':LCD_cmd(0xc0);
		 LCD_str("Bulb 3 is OFF");
		 IOSET0|=1<<5;
		 delay_s(2);
		 break;
case '7':LCD_cmd(0xc0);
		 LCD_str("Bulb 4 is ON");
		 IOCLR0|=1<<6;
		 delay_s(2);
		 break;
case '8':LCD_cmd(0xc0);
		 LCD_str("Bulb 4 is OFF");
		 IOSET0|=1<<6;
		 delay_s(2);
		 break;
}

}
}
