void LCD_init(void);
void LCD_cmd(unsigned char);
void LCD_data(unsigned char);
void LCD_int(int);
void LCD_str(unsigned char *);
void LCD_float(float f);

#define LCD 0xff<<10
#define RS 0x01<<8
#define E 0x01<<9

void LCD_init(void)
{
IODIR0=LCD|RS|E;
LCD_cmd(0x01);
LCD_cmd(0x02);
LCD_cmd(0x0c);
LCD_cmd(0x38);
}

void LCD_cmd(unsigned char c)
{
IOCLR0=LCD;
IOSET0=c<<10;
IOCLR0=RS;
IOSET0=E;
delay_ms(2);
IOCLR0=E;
}

void LCD_data(unsigned char d)
{
IOCLR0=LCD;
IOSET0=d<<10;
IOSET0=RS;
IOSET0=E;
delay_ms(2);
IOCLR0=E;
}


void LCD_int(int n)
{
int i=0;
char arr[5];
if(n==0)
LCD_data('0');
else
{
if(n<0)
{
LCD_data('-');
n=-n;
}
while(n>0)
{
arr[i++]=n%10;
n=n/10;
}
for(--i;i>=0;i--)
LCD_data(arr[i]+48);
}
}

void LCD_str(unsigned char *s)
{
while(*s)
LCD_data(*s++);
}

void LCD_float(float f)
{
int temp =f;
LCD_int(temp);
LCD_data('.');
temp=(f-temp)*1000;
LCD_int(temp);
}