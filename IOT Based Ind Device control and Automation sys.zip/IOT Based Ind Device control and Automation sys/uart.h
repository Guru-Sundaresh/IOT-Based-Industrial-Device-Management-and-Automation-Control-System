void UART0_init(void);
void UART0_STR(unsigned char * );
void UART0_TX(unsigned char);
unsigned char UART0_RX(void);
void UART1_init(void);
void UART1_STR(unsigned char * );
void UART1_TX(unsigned char);
unsigned char UART1_RX(void);

unsigned char UART0_RX(void)
{
while((U0LSR&1)==0);
return U0RBR;
}

void UART0_TX(unsigned char tx)
{
while(((U0LSR>>5)&1)==0);
U0THR=tx;
}

void UART0_init(void)
{
PINSEL0=0x05;
U0LCR=0x83;
U0DLL=97;
U0DLM=0;
U0LCR=0x03;
}

void UART0_STR(unsigned char *s)
{
while(*s)
{
while(((U0LSR>>5)&1)==0);
U0THR=*s++;
}
}

unsigned char UART1_RX(void)
{
while((U1LSR&1)==0);
return U1RBR;
}

void UART1_TX(unsigned char tx)
{
while(((U1LSR>>5)&1)==0);
U1THR=tx;
}

void UART1_init(void)
{
PINSEL0=1<<16|1<<18;
U1LCR=0x83;
U1DLL=97;
U1DLM=0;
U1LCR=0x03;
}

void UART1_STR(unsigned char *s)
{
while(*s)
{
while(((U1LSR>>5)&1)==0);
U1THR=*s++;
}
}

